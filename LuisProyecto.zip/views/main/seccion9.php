<div class="seccion9 container-fluid d-flex align-items-center justify-content-center p-3">
    <div class="container seccion9-interno">
        <picture data-aos="fade-right" class="">
            <source srcset="/build/img/imagenReferencia.avif" type="image/avif">
            <source srcset="/build/img/imagenReferencia.webp" type="image/webp">
        
            <img width="100%" src="/build/img/imagenReferencia.png" alt="imagenReferencia">
        </picture>
        <div data-aos="fade-left" class="contactanos p-4 rounded-3 d-flex flex-column align-items-center display-5">
            <h2 class="text-black fw-bold display-5 text-center mb-5">¡Contactanos!</h2>

            <div>
                <a class="d-block mb-3"href="#"><i class="bi bi-whatsapp"></i> +57 311 2464261</a>
                <a class="d-block mb-3"href="#"><i class="bi bi-envelope"></i></i> correo@glsingenieria.com</a>
                <a class="d-block"href="#"><i class="bi bi-instagram"></i></i> @instragram</a>
            </div>
        </div>
    </div>
</div>