<div class="seccion1  container-fluid position-relative p-0">
    <div class="informacion-seccion1 overflow-hidden container-fluid">
            <picture class="text-center">
                <source srcset="/build/img/logoPrincipal.avif" type="image/avif">
                <source srcset="/build/img/logoPrincipal.webp" type="image/webp">
            
                <img class="animate__animated animate__fadeInLeft col-10 col-md-6" src="/build/img/logoPrincipal.png" alt="logoPrincipal">
            </picture>
            <div class="animate__animated animate__fadeInRight text-center text-white">
                <h3 class="display-4 fw-bold">Consultoría Especializada en</h3>
                <h3 class="display-4 fw-bold">Geología - Geofísica - Estudios Ambientales</h3>
            </div>

    </div>

    <i class="bi bi-caret-down-fill position-absolute top-100 start-50 translate-middle display-1 text-white"></i>
</div>