<div class="seccion2 overflow-hidden container-fluid d-flex align-items-center justify-content-center">
    <div class="container p-0 contenedor-seccion2 text-white">
        <div data-aos="fade-right" class="container p-3 p-md-5">
            <div class="contenedor-chevron d-flex display-3 justify-content-center">
                <i class="bi bi-chevron-right"></i>
                <i class="bi bi-chevron-right"></i>
                <i class="bi bi-chevron-right"></i>
                <i class="bi bi-chevron-right"></i>
                <i class="bi bi-chevron-right"></i>
                <i class="bi bi-chevron-right"></i>
                <i class="bi bi-chevron-right"></i>
                <i class="bi bi-chevron-right"></i>
            </div>

            <h2 class="display-2 fw-bold">La mejor opcion para tus tramites, estimacion y gestion de la informacion geografica</h2>
        </div>
        <div data-aos="flip-right" id="contenedor-2-seccion2" class="p-3 p-md-5 container d-flex flex-column justify-content-around">
            <p class="fs-1 text-black">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Earum deleniti praesentium voluptatibus tenetur eos ipsa, dolores et nisi sequi tempore incidunt unde. Maxime praesentium itaque nihil quidem, soluta incidunt eaque!</p>
            <button type="button" class="btn d-flex align-items-center fw-bold text-uppercase justify-content-center col-12 col-md-8 fs-1 d-block mx-auto">Conoce más</button>
        </div>
    </div>
</div>