<?php include_once __DIR__ . '/seccion1.php' ?>
<?php include_once __DIR__ . '/seccion2.php' ?>
<?php include_once __DIR__ . '/seccion3.php' ?>
<?php include_once __DIR__ . '/seccion4.php' ?>
<?php include_once __DIR__ . '/seccion5.php' ?>
<?php include_once __DIR__ . '/seccion6.php' ?>
<?php include_once __DIR__ . '/seccion7.php' ?>
<?php include_once __DIR__ . '/seccion8.php' ?>